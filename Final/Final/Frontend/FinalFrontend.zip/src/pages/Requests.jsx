import React, { useState } from "react";
import { PlusCircle, Clock } from "lucide-react";

export default function PostRequests() {
  const [requests, setRequests] = useState([
    {
      title: "Need help with BFS/DFS",
      subject: "Algorithms",
      level: "Undergrad",
      credits: 30,
      createdAt: Date.now(),
    },
    {
      title: "IELTS speaking partner",
      subject: "English",
      level: "General",
      credits: 20,
      createdAt: Date.now(),
    },
  ]);

  const [form, setForm] = useState({
    title: "",
    subject: "",
    level: "Undergrad",
    credits: 10,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.title.trim() || !form.subject.trim()) return;

    const newRequest = {
      ...form,
      createdAt: Date.now(),
    };

    setRequests((prev) => [newRequest, ...prev]);
    setForm({ title: "", subject: "", level: "Undergrad", credits: 10 });
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <section className="max-w-6xl mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-2">Post Requests</h1>
        <p className="text-gray-600 mb-8 text-sm md:text-base">
          Post your learning or collaboration requests here. Each post costs credits — earned back when you help others.
        </p>

        {/* Post Form */}
        <form
          onSubmit={handleSubmit}
          className="bg-white border border-gray-200 rounded-xl shadow-sm p-5 md:p-6 grid gap-4 mb-10"
        >
          <h2 className="text-lg font-semibold mb-2 flex items-center gap-2">
            <PlusCircle size={20} className="text-indigo-600" />
            Create a New Request
          </h2>

          <div className="grid md:grid-cols-2 gap-4">
            <input
              name="title"
              value={form.title}
              onChange={handleChange}
              placeholder="Request title (e.g. Need help with calculus homework)"
              className="rounded-lg border px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
              required
            />
            <input
              name="subject"
              value={form.subject}
              onChange={handleChange}
              placeholder="Subject (e.g. Mathematics)"
              className="rounded-lg border px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
              required
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <select
              name="level"
              value={form.level}
              onChange={handleChange}
              className="rounded-lg border px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
            >
              <option>High School</option>
              <option>Undergrad</option>
              <option>Graduate</option>
              <option>Professional</option>
            </select>
            <input
              type="number"
              name="credits"
              value={form.credits}
              onChange={handleChange}
              placeholder="Credits (default 10)"
              className="rounded-lg border px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
              min="10"
            />
          </div>

          <button
            type="submit"
            className="bg-indigo-900 hover:bg-indigo-700 text-white font-medium px-5 py-2 rounded-lg w-fit"
          >
            Post Request
          </button>
        </form>

        {/* Request List */}
        <div>
          <h2 className="text-xl font-semibold mb-4">All Requests</h2>
          {requests.length === 0 ? (
            <div className="text-center py-12 border rounded-lg bg-white text-gray-600">
              No requests yet. Post your first one!
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
              {requests.map((req, i) => (
                <div
                  key={i}
                  className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm hover:shadow-md transition"
                >
                  <h3 className="font-semibold text-lg">{req.title}</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {req.subject} • {req.level}
                  </p>
                  <div className="flex items-center justify-between mt-4 text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <Clock size={14} />
                      {new Date(req.createdAt).toLocaleString()}
                    </div>
                    <span className="text-indigo-700 font-medium">
                      {req.credits} credits
                    </span>
                  </div>
                  <button className="mt-4 w-full bg-indigo-900 hover:bg-indigo-700 text-white rounded-lg py-2 text-sm font-medium">
                    Accept Request
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
