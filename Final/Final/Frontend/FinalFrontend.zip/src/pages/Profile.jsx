import React, { useState } from "react";
import { Menu, X, User, Lock, CreditCard, Award } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function Profile() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navigate = useNavigate();

  const [profile, setProfile] = useState(() => {
    const savedUser = localStorage.getItem('user');
    return savedUser ? JSON.parse(savedUser) : {
      fullName: "Alex Chen",
      email: "alex.chen@university.edu",
      expertise: "Math, Physics",
      bio: "Passionate learner and tutor in Math and Physics. Helping others learn is the best way to grow.",
    };
  });

  const [passwords, setPasswords] = useState({
    current: "",
    new: "",
    confirm: "",
  });

  const handleProfileChange = (e) => {
    const { name, value } = e.target;
    setProfile((prev) => ({ ...prev, [name]: value }));
  };

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setPasswords((prev) => ({ ...prev, [name]: value }));
  };

  const handleSaveProfile = (e) => {
    e.preventDefault();
    localStorage.setItem('user', JSON.stringify(profile));
    alert("Profile updated successfully!");
  };

  const handleChangePassword = (e) => {
    e.preventDefault();
    if (passwords.new !== passwords.confirm) {
      alert("New passwords do not match!");
      return;
    }
    alert("Password changed (demo).");
  };

  return (
    <div className="flex min-h-screen bg-gray-50 text-gray-900 relative">
      

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-white border-b border-gray-200 md:hidden">
          <button
            className="text-gray-600"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu size={22} />
          </button>
          <h2 className="font-semibold text-lg">My Profile</h2>
        </div>

        <div className="flex-1 px-4 md:px-8 py-8 overflow-y-auto">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-2xl md:text-3xl font-bold mb-1">Profile Settings</h1>
            <p className="text-gray-500 mb-6 text-sm md:text-base">
              Manage your personal information, bio, and password.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
              <StatCard icon={<CreditCard />} title="Credits Left" value="247" />
              <StatCard icon={<Award />} title="Credits Used" value="153" />
              <StatCard icon={<User />} title="Sessions Completed" value="42" />
            </div>

            {/* Profile Form */}
            <form
              onSubmit={handleSaveProfile}
              className="bg-white border border-gray-200 rounded-xl shadow-sm p-6 mb-8"
            >
              <h2 className="font-semibold text-lg mb-4">Edit Profile</h2>
              <div className="grid gap-4">
                <input
                  name="fullName"
                  value={profile.fullName}
                  onChange={handleProfileChange}
                  placeholder="Full Name"
                  className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
                <input
                  name="email"
                  type="email"
                  value={profile.email}
                  onChange={handleProfileChange}
                  placeholder="Email"
                  className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
                <input
                  name="expertise"
                  value={profile.expertise}
                  onChange={handleProfileChange}
                  placeholder="Expertise (e.g., Math, Physics)"
                  className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
                <textarea
                  name="bio"
                  value={profile.bio}
                  onChange={handleProfileChange}
                  placeholder="Write a short bio..."
                  rows={4}
                  className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                ></textarea>
              </div>
              <button
                type="submit"
                className="mt-5 bg-indigo-900 hover:bg-indigo-700 text-white px-5 py-2 rounded-lg text-sm font-medium"
              >
                Save Changes
              </button>
            </form>

            {/* Change Password */}
            <form
              onSubmit={handleChangePassword}
              className="bg-white border border-gray-200 rounded-xl shadow-sm p-6"
            >
              <h2 className="font-semibold text-lg mb-4">Change Password</h2>
              <div className="grid gap-4">
                <input
                  type="password"
                  name="current"
                  value={passwords.current}
                  onChange={handlePasswordChange}
                  placeholder="Current Password"
                  className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
                <input
                  type="password"
                  name="new"
                  value={passwords.new}
                  onChange={handlePasswordChange}
                  placeholder="New Password"
                  className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
                <input
                  type="password"
                  name="confirm"
                  value={passwords.confirm}
                  onChange={handlePasswordChange}
                  placeholder="Confirm New Password"
                  className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
              <button
                type="submit"
                className="mt-5 bg-indigo-900 hover:bg-indigo-700 text-white px-5 py-2 rounded-lg text-sm font-medium"
              >
                Update Password
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

/* -------------------------
   Reusable Components
------------------------- */
function NavItem({ label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`w-full text-left px-3 py-2 rounded-lg flex items-center justify-between text-sm font-medium transition ${
        active
          ? "bg-indigo-50 text-indigo-700"
          : "text-gray-600 hover:bg-gray-50 hover:text-indigo-600"
      }`}
    >
      <span>{label}</span>
    </button>
  );
}

function StatCard({ icon, title, value }) {
  return (
    <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm flex items-center gap-3">
      <div className="bg-indigo-100 text-indigo-700 p-2 rounded-lg">{icon}</div>
      <div>
        <p className="text-sm text-gray-500">{title}</p>
        <h3 className="text-lg font-semibold">{value}</h3>
      </div>
    </div>
  );
}
