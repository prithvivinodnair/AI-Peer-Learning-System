import { withAuth } from "next-auth/middleware";

export default withAuth({
  callbacks: {
    authorized: ({ token }) => !!token,
  },
});

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/messages/:path*",
    "/profile/:path*",
    "/booking/:path*",
    "/requests/:path*",
    "/postrequest/:path*",
    "/sessions/:path*",
    "/resources/:path*",
    "/browse/:path*",
    "/course/:path*",
    "/findpartners/:path*",
    "/assistant/:path*",
    "/payment/:path*",
    "/notifications/:path*"
  ],
};
