"use client";

import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import { useEffect, useState } from "react";

export default function Page() {
  const router = useRouter();
  const { data: session, status } = useSession();

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login");
    }
  }, [status, router]);

  if (status === "loading") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        Loading...
      </div>
    );
  }

  if (!session) return null;

  const [form, setForm] = useState({
    subject: "",
    message: "",
    tutor_id: "", // until tutor UI is built
    level: "Undergrad",
    budget: "",
    details: "",
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!form.subject.trim() || !form.message.trim()) {
      alert("Subject and message are required");
      return;
    }

    const res = await fetch("/api/requests", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      cache: "no-store",
      body: JSON.stringify({
        tutor_id: Number(form.tutor_id), // must be number
        subject: form.subject,
        message: form.message,
      }),
    });

    if (res.ok) {
      alert("Request posted successfully!");
      router.push("/requests"); // send back to main Requests page
    } else {
      alert("Error posting request");
    }
  };

  return (
    <section className="container py-10">
      <h2 className="text-2xl font-bold mb-4">Post a learning request</h2>

      <form onSubmit={submit} className="card grid gap-4">

        {/* Subject */}
        <input
          name="subject"
          value={form.subject}
          onChange={handleChange}
          placeholder="Subject (e.g., Algorithms)"
          className="rounded-xl border px-4 py-2"
          required
        />

        {/* Message */}
        <input
          name="message"
          value={form.message}
          onChange={handleChange}
          placeholder="Title (e.g., Need help with DP)"
          className="rounded-xl border px-4 py-2"
          required
        />

        {/* Level */}
        <select
          name="level"
          value={form.level}
          onChange={handleChange}
          className="rounded-xl border px-4 py-2"
        >
          <option>High School</option>
          <option>Undergrad</option>
          <option>Grad</option>
        </select>

        {/* Budget */}
        <input
          type="number"
          name="budget"
          value={form.budget}
          onChange={handleChange}
          placeholder="Budget ($)"
          className="rounded-xl border px-4 py-2"
        />

        {/* Details */}
        <textarea
          name="details"
          value={form.details}
          onChange={handleChange}
          rows={5}
          placeholder="Describe what you need…"
          className="rounded-xl border px-4 py-2"
        />

        {/* Tutor ID (TEMPORARY) */}
        <input
          name="tutor_id"
          value={form.tutor_id}
          onChange={handleChange}
          placeholder="Tutor ID (temporary)"
          className="rounded-xl border px-4 py-2"
          required
        />

        <button className="btn btn-primary w-fit">Submit</button>
      </form>
    </section>
  );
}
