"use client";

import React, { useState, useEffect } from "react";
import { Send } from "lucide-react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";

interface Message {
  id: number;
  sender_id: number;
  receiver_id: number;
  content: string;
  created_at: string;
}

interface ChatUser {
  id: number;
  name: string;
}

export default function Page() {
  const router = useRouter();
  const { data: session, status } = useSession();

  const [users, setUsers] = useState<ChatUser[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [selectedUser, setSelectedUser] = useState<ChatUser | null>(null);
  const [input, setInput] = useState("");

  useEffect(() => {
    if (status === "unauthenticated") router.push("/login");
  }, [status, router]);

  if (status === "loading") {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  if (!session) return null;

  // Load chat list & messages
  useEffect(() => {
    async function loadData() {
      if (!session?.user?.id) return;
      
      try {
        const msgs = await fetch("/api/messages").then(r => r.json());

        // 1) set messages
        setMessages(msgs);

        // 2) build unique chat partners
        const currentUserId = parseInt(session.user.id);
        const map: Record<number, ChatUser> = {};
        msgs.forEach((m: Message) => {
          const uid =
            m.sender_id === currentUserId ? m.receiver_id : m.sender_id;

          map[uid] = { id: uid, name: "User " + uid };
        });

        setUsers(Object.values(map));
      } catch (e) {
        console.log("Error loading messages", e);
      }
    }

    loadData();
  }, [session]);

  // Filter messages for selected chat
  const currentUserId = session?.user?.id ? parseInt(session.user.id) : 0;
  const chatMessages = selectedUser
    ? messages.filter(
        (m) =>
          (m.sender_id === currentUserId &&
            m.receiver_id === selectedUser.id) ||
          (m.sender_id === selectedUser.id &&
            m.receiver_id === currentUserId)
      )
    : [];

  // Send message
  const handleSend = async () => {
    if (!input.trim() || !selectedUser) return;

    await fetch("/api/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        receiver_id: selectedUser.id,
        content: input.trim(),
      }),
    });

    // Optimistic update
    setMessages((prev) => [
      ...prev,
      {
        id: Date.now(),
        sender_id: parseInt(session.user.id),
        receiver_id: selectedUser.id,
        content: input.trim(),
        created_at: new Date().toISOString(),
      },
    ]);

    setInput("");
  };

  return (
    <div className="flex min-h-screen bg-gray-50 text-gray-900 relative">
      <div className="flex-1 flex flex-col">
        <div className="flex flex-1 overflow-hidden">

          {/* LEFT SIDEBAR USER LIST */}
          <div className="hidden md:flex flex-col w-72 border-r bg-white">
            <div className="px-4 py-3 border-b">
              <h2 className="font-semibold text-lg">Chats</h2>
            </div>

            <div className="flex-1 overflow-y-auto">
              {users.map((u) => (
                <button
                  key={u.id}
                  onClick={() => setSelectedUser(u)}
                  className={`w-full text-left px-4 py-3 border-b hover:bg-gray-50 transition ${
                    selectedUser?.id === u.id ? "bg-indigo-50" : ""
                  }`}
                >
                  <h3 className="font-medium text-gray-800">{u.name}</h3>
                  <p className="text-sm text-gray-500 truncate">
                    Chat with {u.name}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* CHAT WINDOW */}
          <div className="flex-1 flex flex-col bg-gray-50">
            {selectedUser ? (
              <>
                {/* Header */}
                <div className="flex items-center justify-between px-4 py-3 border-b bg-white">
                  <h3 className="font-semibold text-lg">{selectedUser.name}</h3>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto px-4 py-4">
                  {chatMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`mb-4 flex ${
                        msg.sender_id === currentUserId
                          ? "justify-end"
                          : "justify-start"
                      }`}
                    >
                      <div
                        className={`rounded-lg px-4 py-2 text-sm ${
                          msg.sender_id === currentUserId
                            ? "bg-indigo-900 text-white"
                            : "bg-gray-200 text-gray-800"
                        }`}
                      >
                        <p>{msg.content}</p>
                        <p className="text-[10px] text-gray-400 mt-1 text-right">
                          {new Date(msg.created_at).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Input */}
                <div className="flex items-center gap-2 p-4 border-t bg-white">
                  <input
                    type="text"
                    placeholder="Type your message..."
                    className="flex-1 bg-gray-100 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSend()}
                  />
                  <button
                    onClick={handleSend}
                    className="bg-indigo-900 hover:bg-indigo-700 text-white p-2 rounded-lg"
                  >
                    <Send size={18} />
                  </button>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-gray-500">
                Select a chat to start messaging.
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
}
