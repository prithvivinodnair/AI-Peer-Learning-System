import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import bcrypt from "bcryptjs";
import { db } from "@/src/lib/db";

export async function POST(req: Request) {
  const session = await getServerSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { current, new: newPassword } = await req.json();

  const [rows] = await db.query(
    "SELECT password FROM users WHERE id = ?",
    [session.user.id]
  );

  const valid = await bcrypt.compare(current, rows[0].password);
  if (!valid) {
    return NextResponse.json({ error: "Incorrect current password" }, { status: 400 });
  }

  const hashed = await bcrypt.hash(newPassword, 10);

  await db.query(
    "UPDATE users SET password = ? WHERE id = ?",
    [hashed, session.user.id]
  );

  return NextResponse.json({ message: "Password updated" });
}
