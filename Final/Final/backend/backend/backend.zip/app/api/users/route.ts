import { NextResponse } from "next/server";
import { db } from "@/src/lib/db";
import bcrypt from "bcryptjs";

export async function GET() {
  const [rows] = await db.query("SELECT id, name, email, role FROM users");
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  const { name, email, password } = body;

  const hashed = await bcrypt.hash(password, 10);

  await db.query(
    "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'user')",
    [name, email, hashed]
  );

  return NextResponse.json({ message: "User created" });
}
