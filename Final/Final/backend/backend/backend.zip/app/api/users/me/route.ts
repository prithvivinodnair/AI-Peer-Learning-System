import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { db } from "@/src/lib/db";

export async function GET() {
  const session = await getServerSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const [rows] = await db.query(
    "SELECT id, name, email, expertise, bio, credits_earned, credits_spent, total_credits FROM users WHERE id = ?",
    [session.user.id]
  );

  return NextResponse.json(rows[0]);
}

export async function PATCH(req: Request) {
  const session = await getServerSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();
  const { name, expertise, bio } = body;

  await db.query(
    "UPDATE users SET name = ?, expertise = ?, bio = ? WHERE id = ?",
    [name, expertise, bio, session.user.id]
  );

  return NextResponse.json({ message: "Profile updated" });
}
