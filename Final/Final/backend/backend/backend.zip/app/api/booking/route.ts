import { NextResponse } from "next/server";
import { db } from "@/src/lib/db";
import { getServerSession } from "next-auth";

export async function GET() {
  const session = await getServerSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const userId = session.user.id;

  const [rows] = await db.query(
    `SELECT * FROM bookings 
     WHERE student_id = ? OR tutor_id = ?
     ORDER BY session_time ASC`,
    [userId, userId]
  );

  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const session = await getServerSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

 const { request_id, student_id, tutor_id, session_time } = await req.json();
  
  // Validate that tutor_id is provided
  if (!tutor_id) {
    return NextResponse.json({ error: "tutor_id is required" }, { status: 400 });
  }

  // Validate that request_id exists if provided
  if (request_id) {
    const result: any = await db.query(
      `SELECT id FROM requests WHERE id = ?`,
      [request_id]
    );
    
    const requestRows = result[0] as any[];
    
    if (!requestRows || requestRows.length === 0) {
      return NextResponse.json({ error: "Invalid request_id: request does not exist" }, { status: 400 });
    }
  }


await db.query(
  `INSERT INTO bookings (request_id, student_id, tutor_id, session_time)
   VALUES (?, ?, ?, ?)`,
  [request_id, student_id, tutor_id, session_time]
);


  return NextResponse.json({ message: "Booking created" });
}
