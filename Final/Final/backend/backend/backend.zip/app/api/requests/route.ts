import { NextResponse } from "next/server";
import { db } from "@/src/lib/db";
import { getServerSession } from "next-auth";

// GET all requests for logged-in user (student or tutor)
export async function GET() {
  const session = await getServerSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const userId = session.user.id;

  const [rows] = await db.query(
    `SELECT * FROM requests 
     WHERE student_id = ? OR tutor_id = ?
     ORDER BY created_at DESC`,
    [userId, userId]
  );

  return NextResponse.json(rows);
}

// POST create a new request
export async function POST(req: Request) {
  const session = await getServerSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const studentId = session.user.id;
  const { tutor_id, subject, message } = await req.json();

  await db.query(
    `INSERT INTO requests (student_id, tutor_id, subject, message)
     VALUES (?, ?, ?, ?)`,
    [studentId, tutor_id, subject, message]
  );

  return NextResponse.json({ message: "Request sent" });
}
