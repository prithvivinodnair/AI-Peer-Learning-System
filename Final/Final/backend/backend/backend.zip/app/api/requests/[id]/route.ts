import { NextResponse } from "next/server";
import { db } from "@/src/lib/db";
import { getServerSession } from "next-auth";

export async function PUT(req: Request, { params }: any) {
  const session = await getServerSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const requestId = params.id;
  const { status } = await req.json(); // accepted OR declined

  await db.query(
    "UPDATE requests SET status = ? WHERE id = ?",
    [status, requestId]
  );

  return NextResponse.json({ message: "Request updated" });
}
