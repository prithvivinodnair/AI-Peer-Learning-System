import { NextResponse } from "next/server";
import { db } from "@/src/lib/db";
import { getServerSession } from "next-auth";

// GET messages of logged-in user
export async function GET() {
  const session = await getServerSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const userId = session.user.id;

  const [rows] = await db.query(
    `SELECT * FROM messages 
     WHERE sender_id = ? OR receiver_id = ?
     ORDER BY created_at ASC`,
    [userId, userId]
  );

  return NextResponse.json(rows);
}

// POST send message
export async function POST(req: Request) {
  const session = await getServerSession();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const userId = session.user.id;
  const body = await req.json();

  const { receiver_id, content } = body;

  await db.query(
    "INSERT INTO messages (sender_id, receiver_id, content) VALUES (?, ?, ?)",
    [userId, receiver_id, content]
  );

  return NextResponse.json({ message: "Message sent" });
}
